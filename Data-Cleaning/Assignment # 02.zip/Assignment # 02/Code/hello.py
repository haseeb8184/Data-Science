import re
import pandas as pd
File = 'D:/University/4th Semester/Data Science/Assignments/Assignment # 02/Code/dawn.csv'
df = pd.read_csv(File)

print(df.head())

# remove " https// " from 1st Column
column_A = 'text-3 href'  
df[column_A] = df[column_A].str.replace('https://', '')
print(df.head(10))

# remove special character from Last Column
column_H = 'story__link' 
characters = '\"\#\$\%\&\'\(\)\*\+\,\-\.\/\:\;\<\=\>\?\@\[\\\\\]\^\_\`\{\|\}\~' 
df[column_H] = df[column_H].str.replace(characters, '')
print(df.head(10))
print(df[column_H])

#remove date from Column G
Column_G = 'timestamp--time'
df[Column_G] = pd.to_datetime(df[Column_G])
df[Column_G] = df[Column_G].dt.date
print(df[Column_G])

# remove "https://www.dawn.com/news/" from  Column
column_D = 'story__link href'  
df[column_D] = df[column_D].str.replace('https://www.dawn.com/news/', '')
print(df[column_D])

# remove first 3 words from Column E
column_E = 'story__excerpt'
df[column_E] = df[column_E].str.split().str[3:].str.join(' ')
print(df[column_E])

# Concatenate 2 Columns
df['Concatenate'] = df['story__link'] + ' ' + df['story__excerpt']
print(df['Concatenate'])

# Save the modified DataFrame to a new CSV file
output_file_path = 'D:/University/4th Semester/Data Science/Assignments/Assignment # 02/Code/dawn_modified.csv'
df.to_csv(output_file_path, index=False)

print("CSV file has been created successfully.")

# Creating Files on the Basis of Categories
categories = df['text-3'].unique()

for category in categories:
    category_df = df[df['text-3'] == category]
    
    file_path = f'D:/University/4th Semester/Data Science/Assignments/Assignment # 02/Code/{category}.csv'
    
    category_df.to_csv(file_path, index=False)
    
    print(f'File saved for category {category} at {file_path}')
